<div class="bg-light p-3 text-center">
            <p>All rights reserved @FurrCare</p>
        </div>