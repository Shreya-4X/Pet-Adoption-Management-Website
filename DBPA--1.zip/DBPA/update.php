<?php
include 'admin_panel.php';

$id = $_GET['updateid'];

// Fetch data from the database based on the provided ID
$sql = "SELECT * FROM animal_listings WHERE id=$id";
$result = mysqli_query($con, $sql);
$row = mysqli_fetch_assoc($result);

// Populate variables with fetched data
$animal_type = $row['animal_type'];
$breed = $row['breed'];
$age = $row['age'];
$size = $row['size'];
$temperament = $row['temperament'];
$traits = $row['traits'];

if(isset($_POST['submit'])){
    // Retrieve updated values from the form
    $animal_type = $_POST['animal_type'];
    $breed = $_POST['breed'];
    $age = $_POST['age'];
    $size = $_POST['size'];
    $temperament = $_POST['temperament'];
    $traits = $_POST['traits'];

    // Update the record in the database
    $sql = "UPDATE animal_listings SET animal_type='$animal_type', breed='$breed', age='$age', size='$size', temperament='$temperament', traits='$traits' WHERE id=$id";

    $result = mysqli_query($con, $sql);
    if($result){
        header('location:display.php');
        exit; // Stop further execution after redirect
    } else {
        die(mysqli_error($con));
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
    <div class="container my-5">
        <form method="post">
            <div class="mb-3">
              <label>Animal Type</label>
              <input type="text" class="form-control" placeholder="Enter the animal type" name="animal_type" autocomplete="off" value="<?php echo $animal_type; ?>">
            </div>
            <div class="mb-3">
                <label>Breed</label>
                <input type="text" class="form-control" placeholder="Enter the breed" name="breed" autocomplete="off" value="<?php echo $breed; ?>">
            </div>
            <div class="mb-3">
                <label>Age</label>
                <input type="text" class="form-control" placeholder="Enter the age" name="age" autocomplete="off" value="<?php echo $age; ?>">
            </div>
            <div class="mb-3">
                <label>Size</label>
                <input type="text" class="form-control" placeholder="Enter the size" name="size" autocomplete="off" value="<?php echo $size; ?>">
            </div>
            <div class="mb-3">
                <label>Temperament</label>
                <input type="text" class="form-control" placeholder="Enter the temperament" name="temperament" autocomplete="off" value="<?php echo $temperament; ?>">
            </div>
            <div class="mb-3">
                <label>Traits</label>
                <input type="text" class="form-control" placeholder="Enter the traits" name="traits" autocomplete="off" value="<?php echo $traits; ?>">
            </div>
            <button type="submit" name="submit" class="btn btn-primary">Update</button> &nbsp; <button class="btn btn-primary my-5"><a href="display.php" class="text-light">Cancel</a></button>

        </form>
    </div>
</body>
</html>