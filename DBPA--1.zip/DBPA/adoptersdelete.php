<?php
include 'admin_panel.php';
if(isset($_GET['deleteid'])){
    $id=$_GET['deleteid'];

    $sql="delete from manage_user where id=$id";
    $result=mysqli_query($con,$sql); // Corrected function call
    if($result){
        header('location:manage_users.php');
    }
    else{
        die(mysqli_error($con));
    }
}
?>