<?php
$newUsername = $_POST['newUsername'];
$newPassword = $_POST['newPassword'];

// Database connection
$conn = new mysqli('localhost', 'root', '', 'test1');
if ($conn->connect_error) {
    die('Connection failed : ' . $conn->connect_error);
} else {
    // Check if the username already exists
    $check_stmt = $conn->prepare("SELECT * FROM login WHERE newUsername = ?");
    $check_stmt->bind_param("s", $newUsername);
    $check_stmt->execute();
    $result = $check_stmt->get_result();

    if ($result->num_rows > 0) {
        // Username already exists
        echo "Username already taken. Please choose a different username.";
    } else {
        // Username is unique, proceed with insertion
        $insert_stmt = $conn->prepare("INSERT INTO login (newUsername, newPassword) VALUES (?, ?)");
        $insert_stmt->bind_param("ss", $newUsername, $newPassword);
        $insert_stmt->execute();
        // echo "Registration successful";
        header("location: login1.html");
    }

    // Close statements and connection
    $check_stmt->close();
    $insert_stmt->close();
    $conn->close();
}
?>