<?php
include 'admin_panel.php';
if(isset($_POST['submit'])){
    $animal_type=$_POST['animal_type'];
    $breed=$_POST['breed'];
    $age=$_POST['age'];
    $size=$_POST['size'];
    $temperament=$_POST['temperament'];
    $traits=$_POST['traits'];
    $keywords=$_POST['keywords'];
    // Check if file is uploaded successfully
    if(isset($_FILES['picture']) && $_FILES['picture']['error'] === UPLOAD_ERR_OK) {
        // Get the temporary file path
        $tmpFilePath = $_FILES['picture']['tmp_name'];
        // Read the file contents
        $pictureData = file_get_contents($tmpFilePath);
        // Encode the picture data
        $picture = mysqli_real_escape_string($con, $pictureData);
        
        // Insert data into the database
        $sql="INSERT INTO `animal_listings`(animal_type, breed, age, size, temperament, traits,keywords, picture) 
        VALUES ('$animal_type', '$breed', '$age', '$size', '$temperament', '$traits','$keywords', '$picture')";
        $result=mysqli_query($con, $sql);
        if($result){
           header('location:display.php');
           exit();
        } else {
            die(mysqli_error($con));
        }
    } else {
        die("Error uploading file");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
    <div class="container my-5" >
        <form method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label>Animal Type</label>
                <input type="text" class="form-control" placeholder="Enter the animal type" name="animal_type" autocomplete="off">
            </div>
            <div class="mb-3">
                <label>Breed</label>
                <input type="text" class="form-control" placeholder="Enter the breed" name="breed" autocomplete="off">
            </div>
            <div class="mb-3">
                <label>Age</label>
                <input type="text" class="form-control" placeholder="Enter the age" name="age" autocomplete="off">
            </div>
            <div class="mb-3">
                <label>Size</label>
                <input type="text" class="form-control" placeholder="Enter the size" name="size" autocomplete="off">
            </div>
            <div class="mb-3">
                <label>Temperament</label>
                <input type="text" class="form-control" placeholder="Enter the temperament" name="temperament" autocomplete="off">
            </div>
            <div class="mb-3">
                <label>Traits</label>
                <input type="text" class="form-control" placeholder="Enter the traits" name="traits" autocomplete="off">
            </div>
            <div class="mb-3">
                <label>Keywords to search</label>
                <input type="text" class="form-control" placeholder="Enter keywords" name="keywords" autocomplete="off">
            </div>
            <div class="mb-3">
                <label>Picture</label>
                <input type="file" class="form-control" name="picture" accept="image/jpeg, image/png">
            </div> 
            <button type="submit" name="submit" class="btn btn-primary">Submit</button>&nbsp;
            <button class="btn btn-primary my-5"><a href="display.php" style="color: white; text-decoration: none;">Cancel</a></button>

        </form>
    </div>
</body>
</html>