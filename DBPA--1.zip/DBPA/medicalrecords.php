<?php
include 'admin_panel.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Medical Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" 
          rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" 
          crossorigin="anonymous">
    <style>
        body {
            background-color: bisque;
            font-family: 'Arial', sans-serif;
        }

        h2 {
            color: #007bff;
            margin-bottom: 30px;
        }

        .container {
            margin-top: 0%;
        }

        .btn-primary {
            background-color: #28a745;
            border-color: #28a745;
        }

        .btn-primary a {
            color: #fff;
            text-decoration: none;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            border-radius: 10px;
        }

        .table th, .table td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #dee2e6;
        }

        .table th {
            background-color: #007bff;
            color: #fff;
        }

        .table tbody tr:hover {
            background-color: #f0f8ff;
        }

        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
            margin-right: 5px;
        }

        .btn-danger a {
            color: #fff;
            text-decoration: none;
        }

        img {
            max-width: 100px;
            height: auto;
            border-radius: 5px;
        }

        table {
            border: 1px solid;
        }
    </style>
</head>

<body>
    <div class="container">
        <button class="btn btn-primary my-5" onclick="window.location.href='medicolists.php'">Add New Medical Record</button>
        &nbsp;
        <button class="btn btn-primary my-5" onclick="window.location.href='admin_panel.html'">Back</button>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Animal ID</th>
                    <th scope="col">Animal Breed</th>
                    <th scope="col">Diagnosis</th>
                    <th scope="col">Treatment</th>
                    <th scope="col">Treatment Date</th>
                    <th scope="col">Operations</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM medico_records";
                $result = mysqli_query($con, $sql);
                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $id = $row['id'];
                        $breed = $row['breed'];
                        $diagnosis = $row['diagnosis'];
                        $treatment = $row['treatment'];
                        $treatment_date = $row['treatment_date'];

                        echo '<tr>
                            <th scope="row">' . $id . '</th>
                            <td>' . $breed . '</td>
                            <td>' . $diagnosis . '</td>
                            <td>' . $treatment . '</td>
                            <td>' . $treatment_date . '</td>
                            <td>
                                <div class="btn-group">
                                    <button class="btn btn-primary" onclick="window.location.href=\'medicoupdates.php?updateid=' . $id . '\'">Update</button> &nbsp
                                    <button class="btn btn-danger" onclick="window.location.href=\'medicodelete.php?deleteid=' . $id . '\'">Delete</button>
                                </div>
                            </td>
                        </tr>';
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
