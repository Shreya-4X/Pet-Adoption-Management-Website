<?php
include 'admin_panel.php';

if (isset($_POST['submit'])) {
    $adopter_name = $_POST['adopter_name'];
    $adoption_date = $_POST['adoption_date'];
    $adopter_loc = $_POST['adopter_loc'];
    $adopter_contact = $_POST['adopter_contact'];
    $animal_type = $_POST['animal_type'];
    $breed = $_POST['breed'];

    // Insert data into the database
    $sql = "INSERT INTO manage_user (adopter_name, adoption_date, adopter_loc, adopter_contact,animal_type,breed) 
            VALUES ('$adopter_name', '$adoption_date', '$adopter_loc', '$adopter_contact','$animal_type','$breed')";
    $result = mysqli_query($con, $sql);

    if ($result) {
        header('location: manage_users.php');
        exit();
    } else {
        die(mysqli_error($con));
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
    <div class="container my-5" >
        <form method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label>Adopter Name</label>
                <input type="text" class="form-control" placeholder="Enter the User name" name="adopter_name" autocomplete="off">
            </div>
            <div class="mb-3">
                <label>Adoption Date</label>
                <input type="text" class="form-control" placeholder="Enter the Adoption Date" name="adoption_date" autocomplete="off">
            </div>
            <div class="mb-3">
                <label>Adopter Location</label>
                <input type="text" class="form-control" placeholder="Enter the Adopter Location" name="adopter_loc" autocomplete="off">
            </div>
            <div class="mb-3">
                <label>Adopter Contact Details</label>
                <input type="text" class="form-control" placeholder="Enter the Adopter Contact" name="adopter_contact" autocomplete="off">
            </div>
            <div class="mb-3">
                <label>Adopted Animal Type</label>
                <input type="text" class="form-control" placeholder="Enter the Adopted Animal Type" name="animal_type" autocomplete="off" >
            </div>
            <div class="mb-3">
                <label>Adopted Animal Breed</label>
                <input type="text" class="form-control" placeholder="Enter the Adopted Animal Breed" name="breed">
            </div>
            
            
            <button type="submit" name="submit" class="btn btn-primary">Submit</button>&nbsp;<button class="btn btn-primary my-5"><a href="manage_users.php" style="color: white; text-decoration: none;">Cancel</a></button>

        </form>
    </div>
</body>
</html>