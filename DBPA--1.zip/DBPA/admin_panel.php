<?php

$con=new mysqli('localhost','root','','test1');
if(!$con){
    die(mysqli_error($con));

}

?>