<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Static Bar Chart</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" 
          rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" 
          crossorigin="anonymous">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin:30px 20px  ;
            padding: 0;
             background-color: #f4f4f4;
        }

        .content {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .box {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body >    
    <button class="btn btn-primary my-2"><a href="admin_panel.html" class="text-light">Back</a></button>
    <button class="btn btn-primary my-2 logout-btn"><a href="login1.html" class="text-light">Log Out</a></button>

    <h1><center>Bar Chart </h1>

    <div class="content">
        <div class="box">
            <canvas id="barChart" width="400" height="400"></canvas>
        </div>
    </div>

    <script>
        // PHP code to fetch data and encode it as JSON
        <?php
        // Establish database connection
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "test1";

        $conn = new mysqli($servername, $username, $password, $dbname);

        // Execute stored procedure
        $sql = "CALL GetAnimalCounts()";
        $result = $conn->query($sql);

        // Fetch data and encode it as JSON
        $data = array();
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $data[$row['animal_type']] = $row['count'];
            }
        }
        echo "var animalData = " . json_encode($data) . ";";
        ?>

        // Create Chart.js bar chart
        var ctx = document.getElementById('barChart').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: Object.keys(animalData),
                datasets: [{
                    label: 'Animal Counts',
                    data: Object.values(animalData),
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: false, // Disable responsiveness
                legend: {
                    position: 'right',
                },
                animation: {
                    duration: 0 // Disable animations
                }
            }
        });
    </script>
</body>
</html>
