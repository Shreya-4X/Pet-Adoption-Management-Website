<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adoption Form Details</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
<style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-image:url("adoption1.jpg");
            background-size:cover;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #333; /* Dark gray */
        }

        .adoption-forms-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .adoption-form {
            position: relative;
            background-color: #fff; /* White background */
            border-radius: 20px; /* Rounded corners */
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            padding: 20px;
            margin-bottom: 30px;
            width: calc(33.33% - 20px); /* Three boxes in a row with margin */
            transition: transform 0.3s ease, box-shadow 0.3s ease; /* Transition on transform and box-shadow */
            display: flex;
            flex-direction: column;
            position: relative; /* Make it a reference for absolute positioning */
        }

        .adoption-form:hover {
            transform: translateY(-10px); /* Move up slightly on hover */
            box-shadow: 0 6px 30px rgba(0, 0, 0, 0.3); /* Stronger shadow on hover */
        }

        .adoption-form p {
            margin: 10px 0;
            color: #666; /* Dark gray for text */
        }

        hr {
            border: none;
            border-top: 1px solid #eee; /* Light gray line */
            margin: 20px 0;
        }

        .btn-back {
            background-color: #007bff; /* Blue button */
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .btn-back:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }

        .reviewed-button-container {
            position: absolute;
            top: 10px;
            right: 10px;
            display: flex;
            flex-direction: row;
        }

        .reviewed-button {
            background-color: #28a745; /* Green */
            color: #fff;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-left: 5px;
        }

        .reviewed-button:hover {
            background-color: #218838; /* Darker green on hover */
        }

        .accepted {
            background-color: #d4edda; /* Light green for accepted */
        }

        .rejected {
            background-color: #f8d7da; /* Light red for rejected */
        }

        .pending-button {
            position: absolute;
            bottom: 10px;
            right: 10px;
            background-color: #ffc107; /* Yellow */
            color: #212529; /* Black */
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: default;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Adoption Form Details</h2>
        <button class="btn btn-primary mb-4"><a href="admin_panel.html" class="text-light">Back</a></button>
        <div class="adoption-forms-container">
            <?php
            // Include connect file
            include('./includes/connect.php');

            // Fetch adoption form records from the database
            $select_query = "SELECT * FROM adoption_forms";
            $result = mysqli_query($con, $select_query);

            // Check if there are records
            if(mysqli_num_rows($result) > 0) {
                while($row = mysqli_fetch_assoc($result)) {
                    echo '<div class="adoption-form" data-id="' . $row['id'] . '">';
                    echo '<div class="reviewed-button-container">';
                    // Add reviewed buttons
                    echo '<button class="reviewed-button accepted">✓</button>';
                    echo '<button class="reviewed-button rejected">✗</button>';
                    echo '</div>';
                    echo "<p><strong>Name:</strong> " . $row['FirstName'] . " " . $row['LastName'] . "</p>";
                    echo "<p><strong>Email:</strong> " . $row['Email'] . "</p>";
                    echo "<p><strong>Contact Number:</strong> " . $row['ContactNo'] . "</p>";
                    echo "<p><strong>Address:</strong> " . $row['Address'] . "</p>";
                    echo "<p><strong>Animal Type:</strong> " . $row['animal_type'] . "</p>";
                    echo "<p><strong>Animal Breed:</strong> " . $row['breed'] . "</p>";
                    echo '<hr>';
                    // Add pending status button
                    echo '<button class="pending-button">Pending</button>';
                    echo '</div>';
                }
            } else {
                echo "<p class='text-center'>No adoption forms found!</p>";
            }

            // Close the database connection
            mysqli_close($con);
            ?>
        </div>
    </div>

    <script>
        // JavaScript to handle marking adoption forms
        document.addEventListener("DOMContentLoaded", function() {
            const adoptionForms = document.querySelectorAll('.adoption-form');

            adoptionForms.forEach(form => {
                const reviewedButtons = form.querySelectorAll('.reviewed-button');
                const statusButton = form.querySelector('.pending-button');
                const formId = form.dataset.id;

                reviewedButtons.forEach(button => {
                    button.addEventListener('click', function() {
                        // Remove active class from all buttons
                        reviewedButtons.forEach(btn => {
                            btn.classList.remove('active');
                        });

                        // Add active class to the clicked button
                        button.classList.add('active');

                        // Update status based on the clicked button
                        const status = button.classList.contains('accepted') ? 'Accepted' : 'Rejected';
                        statusButton.textContent = status;
                        statusButton.classList.remove('pending');
                        localStorage.setItem('status-' + formId, status.toLowerCase());
                    });
                });



                // Load status from local storage
                const storedStatus = localStorage.getItem('status-' + formId);
                if (storedStatus) {
                    statusButton.textContent = storedStatus.charAt(0).toUpperCase() + storedStatus.slice(1);
                    statusButton.classList.remove('pending');
                    statusButton.classList.add(storedStatus);
                }
            });
        });
    </script>
</body>
</html>
