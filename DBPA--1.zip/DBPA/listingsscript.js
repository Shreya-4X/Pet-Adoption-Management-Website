function showDetails(species, breed, age, size, temperament, behavioralTraits) {
    var detailsContent = document.getElementById('details-content');
    detailsContent.innerHTML = `
        <p><strong>Species:</strong> ${species}</p>
        <p><strong>Breed:</strong> ${breed}</p>
        <p><strong>Age:</strong> ${age}</p>
        <p><strong>Size:</strong> ${size}</p>
        <p><strong>Temperament:</strong> ${temperament}</p>
        <p><strong>Behavioral Traits:</strong> ${behavioralTraits}</p>
    `;
    document.getElementById('animal-details').style.display = 'flex';
  }
  
  function showAdoptionForm() {
    document.getElementById('adoption-form').style.display = 'block';
  }
  
  function submitAdoptionForm() {
    // Handle the form submission, e.g., send data to the server
    alert('Adoption application submitted successfully!');
    hideAdoptionForm();
  }
  
  function cancelAdoptionForm() {
    hideAdoptionForm();
  }
  
  function hideAdoptionForm() {
    document.getElementById('adoption-form').style.display = 'none';
  }
  function showDetails(species, breed, age, size, temperament, behavioralTraits) {
    var detailsContent = document.getElementById('details-content');
    detailsContent.innerHTML = `
        <p><strong>Species:</strong> ${species}</p>
        <p><strong>Breed:</strong> ${breed}</p>
        <p><strong>Age:</strong> ${age}</p>
        <p><strong>Size:</strong> ${size}</p>
        <p><strong>Temperament:</strong> ${temperament}</p>
        <p><strong>Behavioral Traits:</strong> ${behavioralTraits}</p>
    `;
  
    // Show the animal details section
    var animalDetailsSection = document.getElementById('animal-details');
    animalDetailsSection.style.display = 'flex';
  
    // Scroll to the details section
    animalDetailsSection.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
    });
  }
  
  