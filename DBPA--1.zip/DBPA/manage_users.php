<?php
include 'admin_panel.php';


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Adoption Center Adopted Animals Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" 
          rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" 
          crossorigin="anonymous">
          <style>
        body {
            background-color: bisque;
            font-family: 'Arial', sans-serif;
        }

        h2 {
            color: #007bff;
            margin-bottom: 30px;
        }

        .container {
            margin-top: 0%;
        }

        .btn-primary {
            background-color: #28a745;
            border-color: #28a745;
        }

        .btn-primary a {
            color: #fff;
            text-decoration: none;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            border-radius: 10px;
        }

        .table th, .table td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #dee2e6;
        }

        .table th {
            background-color: #007bff;
            color: #fff;
        }

        .table tbody tr:hover {
            background-color: #f0f8ff;
        }
       
        

        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
            margin-right: 5px;
        }

        .btn-danger a {
            color: #fff;
            text-decoration: none;
        }

        img {
            max-width: 100px;
            height: auto;
            border-radius: 5px;
        }
        table{
            border=1;
        }
        
        
    </style>

</head>

<body>
    <div class="container">
        <button class="btn btn-primary my-5"><a href="userslist.php" class="text-light">Add User</a></button> &nbsp;
        <button class="btn btn-primary my-5"><a href="admin_panel.html" class="text-light">Back</a></button>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Animal ID</th>
                    <th scope="col">Adopter Name</th>
                    <th scope="col">Adoption Date</th>
                    <th scope="col">Adopter Location</th>
                    <th scope="col">Adopter Contact Number</th>
                    <th scope="col">Adopted Animal Type</th>
                    <th scope="col">Adopted Animal Breed</th>
                    <th scope="col">Operations</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM manage_user";
                $result = mysqli_query($con, $sql);
                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $id = $row['id'];
                        
                        $adopter_name = $row['adopter_name'];
                        $adoption_date = $row['adoption_date'];
                        $adopter_loc = $row['adopter_loc'];
                        $adopter_contact = $row['adopter_contact'];
                        $animal_type = $row['animal_type'];
                        $breed = $row['breed'];

                        echo '<tr>
                            <th scope="row">' . $id . '</th>
                            <td>' . $adopter_name . '</td>
                            <td>' . $adoption_date . '</td>
                            <td>' . $adopter_loc . '</td>
                            <td>' . $adopter_contact . '</td>
                            <td>' . $animal_type . '</td>
                            <td>' . $breed . '</td>
                            <td>
                            <div class="btn-group">
                            <button class="btn btn-primary"><a href="adoptersupdate.php?updateid=' . $id . '" class="text-light">Update</a></button> &nbsp;
                            <button class="btn btn-danger"><a href="adoptersdelete.php?deleteid=' . $id . '" class="text-light">Delete</a></button>
                        </div>
                            </td>
                        </tr>';
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
