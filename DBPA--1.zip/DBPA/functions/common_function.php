
   <style>
    .card-img-top {
        
        width: 100%; /* Set width to 100% */
        height: 200px; /* Set a fixed height */
        object-fit: cover; /* Ensure the image covers the entire area */
    }

</style>

<?php
// Include connect file
include('./includes/connect.php');

// Define function to get animals details
function getAnimals() {
    global $con; // Access the global variable $con

    //condition to check isset or not
    if (!isset($_GET['animal_type'])){
       
    $select_query = "SELECT * FROM `animal_listings`  " ;
    $result_query = mysqli_query($con, $select_query);
    $num_of_rows=mysqli_num_rows($result_query);
    if($num_of_rows==0){
        echo "<h2 class='text-center text-danger'>No animals available </h2>";
    }

    while ($row = mysqli_fetch_assoc($result_query)) {
        $id = $row['id'];
        $animal_type = $row['animal_type'];
        $breed = $row['breed'];
        $picture = base64_encode($row['picture']); // Encode the image data to base64
        ?>
        <div class="div col-md-4 mb-2">
            <div class="card">
                <img src="data:image/jpeg;base64,<?php echo $picture; ?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title"><?php echo $animal_type; ?></h5>
                    <p class="card-text"><?php echo $breed; ?></p>
                    <a href='adoptionForm.php?adopt_animal=<?php echo $id; ?>'class='btn btn-primary'>Apply to Adopt</a>
                    <a href='animal_details.php?id=<?php echo $id; ?>' class='btn btn-secondary'>View more</a>
                </div>
            </div>
        </div>
    <?php
    }
}
    }

    function getAllAnimals(){
        global $con; // Access the global variable $con

        //condition to check isset or not
        if (!isset($_GET['animal_type'])){
           
        $select_query = "SELECT * FROM animals";
        $result_query = mysqli_query($con, $select_query);
        $num_of_rows=mysqli_num_rows($result_query);
        if($num_of_rows==0){
            echo "<h2 class='text-center text-danger'>No animals available </h2>";
        }
    
        while ($row = mysqli_fetch_assoc($result_query)) {
            $id = $row['id'];
            $animal_type = $row['animal_type'];
            $breed = $row['breed'];
            $picture = base64_encode($row['picture']); // Encode the image data to base64
            ?>
            <div class="div col-md-4 mb-2">
                <div class="card">
                    <img src="data:image/jpeg;base64,<?php echo $picture; ?>" class="card-img-top" alt="...">
                    <div class="card-body ">
                        <h5 class="card-title"><?php echo $animal_type; ?></h5>
                        <p class="card-text"><?php echo $breed; ?></p>
                        <a href='adoptionForm.php?adopt_animal=<?php echo $id; ?>'class='btn btn-primary'>Apply to Adopt</a>
                        <a href='animal_details.php?id=<?php echo $id; ?>' class='btn btn-secondary'>View more</a>
                    </div>
                </div>
            </div>
        <?php
        }
    }
        }

    



//getting unique animals
function getUniqueAnimals() {
    global $con; // Access the global variable $con

    //condition to check isset or not
    if (isset($_GET['animal_type'])){
        $animal=$_GET['animal_type'];
    $select_query = "SELECT * FROM `animal_listings` where id=$animal";
    $result_query = mysqli_query($con, $select_query);

    while ($row = mysqli_fetch_assoc($result_query)) {
        $id = $row['id'];
        $animal_type = $row['animal_type'];
        $breed = $row['breed'];
        $picture = base64_encode($row['picture']); // Encode the image data to base64
        ?>
        <div class="div col-md-4 mb-2">
            <div class="card">
                <img src="data:image/jpeg;base64,<?php echo $picture; ?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title"><?php echo $animal_type; ?></h5>
                    <p class="card-text"><?php echo $breed; ?></p>
                    <a href='adoptionForm.php?adopt_animal=<?php echo $id; ?>'class='btn btn-primary'>Apply to Adopt</a>
                    <a href='animal_details.php?id=<?php echo $id; ?>' class='btn btn-secondary'>View more</a>
                </div>
            </div>
        </div>
    <?php
    }
}
    }



// Call the function to display animals
// getAnimals();

function getAnimalType(){
    global $con;
    $select_animal = "SELECT animal_type, id ,breed FROM `animal_listings` GROUP BY id,animal_type ";
$result_animals = mysqli_query($con, $select_animal);
while ($row_data = mysqli_fetch_assoc($result_animals)) {
$animal_type = $row_data['animal_type'];
$id = $row_data['id'];
$breed=$row_data['breed'];
echo "<li class='nav-tem'>
   <a href='index.php?animal_type=$id' class='nav-link text-light'>$animal_type-$breed</a>
 </li>";
}
}


// search product function
function search_product(){
    global $con; // Access the global variable $con

    //condition to check isset or not
   if(isset($_GET['search_data_product'])){
    $search_data_value=$_GET['search_data'];
    $search_query = "SELECT * FROM `animal_listings` where keywords like '%$search_data_value%'";
    $result_query = mysqli_query($con, $search_query);

    $num_of_rows=mysqli_num_rows($result_query);
    if($num_of_rows==0){
        echo "<h2 class='text-center text-danger'>No Match!</h2>";
    }
    while ($row = mysqli_fetch_assoc($result_query)) {
        $id = $row['id'];
        $animal_type = $row['animal_type'];
        $breed = $row['breed'];
        $picture = base64_encode($row['picture']); // Encode the image data to base64
        ?>
        <div class="div col-md-4 mb-2">
            <div class="card">
                <img src="data:image/jpeg;base64,<?php echo $picture; ?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title"><?php echo $animal_type; ?></h5>
                    <p class="card-text"><?php echo $breed; ?></p>
                    <a href='adoptionForm.php?adopt_animal=<?php echo $id; ?>'class='btn btn-primary'>Apply to Adopt</a>
                    <a href='animal_details.php?id=<?php echo $id; ?>' class='btn btn-secondary'>View more</a>
                </div>
            </div>
        </div>


      
    <?php
    }
}
}


// View details
function view_details() {
    global $con; // Access the global variable $con
    
    // Condition to check if 'animal_id' is set
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $select_query = "SELECT * FROM `animal_listings` WHERE id = $id";
        $result_query = mysqli_query($con, $select_query);
        
        if (mysqli_num_rows($result_query) > 0) {
            $row = mysqli_fetch_assoc($result_query);
            $animal_type = $row['animal_type'];
            $breed = $row['breed'];
            $age = $row['age'];
            $size = $row['size'];
            $temperament = $row['temperament'];
            $traits = $row['traits'];
            $picture = base64_encode($row['picture']); // Encode the image data to base64
            
            // Output HTML for displaying animal details
            echo "<div class='card mb-3'>
                    <div class='row no-gutters'>
                        <div class='col-md-4'>
                            <img src='data:image/jpeg;base64," . $picture . "' class='card-img' alt='...'>
                        </div>
                        <div class='col-md-8'>
                            <div class='card-body'>
                                <h5 class='card-title'>" . $animal_type . "</h5>
                                <p class='card-text'>" . $breed . "</p>
                                <p class='card-text'>Age: " . $age . "</p>
                                <p class='card-text'>Size: " . $size . "</p>
                                <p class='card-text'>Temperament: " . $temperament . "</p>
                                <p class='card-text'>Traits: " . $traits . "</p>
                                <a href='adoptionForm.php?adopt_animal=<?php echo $id; ?>'class='btn btn-primary'>Apply to Adopt</a>
                                </div>
                        </div>
                    </div>
                </div>";
        } else {
            // Animal not found
            echo "<p>Animal not found.</p>";
        }
    }
}

// get ip address function
function getIPAddress() {  
    //whether ip is from the share internet  
     if(!empty($_SERVER['HTTP_CLIENT_IP'])) {  
                $ip = $_SERVER['HTTP_CLIENT_IP'];  
        }  
    //whether ip is from the proxy  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
     }  
//whether ip is from the remote address  
    else{  
             $ip = $_SERVER['REMOTE_ADDR'];  
     }  
     return $ip;  
}  
// $ip = getIPAddress();  
// echo 'User Real IP Address - '.$ip;  


?>




