
<?php
// Include connect file
include('./includes/connect.php');

// Check if the form is submitted
if(isset($_POST['submitAdoption'])) {
    // Retrieve form data
    $FirstName = $_POST['FirstName'];
    $LastName = $_POST['LastName'];
    $Email = $_POST['Email'];
    $ContactNo = $_POST['ContactNo'];
    $Address = $_POST['Address'];
    $animal_type= $_POST['animal_type'];
    $breed= $_POST['breed'];
    
    // Insert data into database
    $insert_query = "INSERT INTO adoption_forms (FirstName,LastName, Email, ContactNo, Address,animal_type,breed) VALUES ('$FirstName', '$LastName','$Email', '$ContactNo', '$Address','$animal_type','$breed')";
    
    if(mysqli_query($con, $insert_query)) {
        echo "<script>alert('Form submitted successfully!');</script>";
    } else {
        echo "<script>alert('Error: " . mysqli_error($con) . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Adoption Form</title>
  <!-- Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="style.css" type="text/css">
  <style>
body{
    background-color:thistle;
}
.navbar {
            background-color:thistle; /* Grey background */
            /* margin-bottom: 20px;  */
            text-color:white;
        }
        .logo{
            width:5%;
            height:5%;
            border-radius:70px 70px;
        }
    </style>
</head>
<body>
 <!-- navbar -->
 <div class="container-fluid p-0">
        <!-- firstchild -->
        <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
                <img src="main.jpg" alt="" class="logo"><h2>FurrCare</h2>&nbsp&nbsp
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.html">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Animals</a>
                        </li>
                       
                    </ul>      </form>
                </div>
            </div>
        </nav>
<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card">
        <div class="card-header">
          Adoption Form
        </div>
        <div class="card-body">
          <form method="POST" action="">
            <div class="form-group">
              <label for="FirstName">First Name:</label>
              <input type="text" class="form-control" id="FirstName" name="FirstName" required>
            </div>
            <div class="form-group">
              <label for="LastName">Last Name:</label>
              <input type="text" class="form-control" id="LastName" name="LastName" required>
            </div>
            <div class="form-group">
              <label for="Email">Email:</label>
              <input type="email" class="form-control" id="Email" name="Email" required>
            </div>
            <div class="form-group">
              <label for="ContactNo">Contact Number:</label>
              <input type="text" class="form-control" id="ContactNo" name="ContactNo" required pattern="\d{10}" title="Please enter a valid 10-digit phone number">
              
            </div>
            <div class="form-group">
              <label for="Address">Address:</label>
              <textarea class="form-control" id="Address" name="Address" rows="3" required></textarea>
            </div>
            <div class="form-group">
              <label for="animal_name">Animal Type:</label>
              <textarea class="form-control" id="animal_type" name="animal_type" rows="3" required></textarea>
            </div>
            <div class="form-group">
              <label for="breed">Animal Breed:</label>
              <textarea class="form-control" id="breed" name="breed" rows="3" required></textarea>
            </div>
            <div class="form-group">
              <button type="submit" name="submitAdoption" class="btn btn-primary">Submit</button>
              <button type="button" class="btn btn-secondary" onclick="cancelForm()">Cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS and jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
  function cancelForm() {
    // Redirect or hide the form as needed
    window.location.href = "index.php"; // Replace with your cancel page URL
  }
</script>

</body>
</html>
