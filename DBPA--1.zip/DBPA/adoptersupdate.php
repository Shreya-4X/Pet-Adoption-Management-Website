<?php
include 'admin_panel.php';

$id = $_GET['updateid'];

// Fetch data from the database based on the provided ID
$sql = "SELECT * FROM manage_user WHERE id=$id";
$result = mysqli_query($con, $sql);
$row = mysqli_fetch_assoc($result);

// Populate variables with fetched data
$adopter_name = $row['adopter_name'];
$adoption_date = $row['adoption_date'];
$adopter_loc = $row['adopter_loc'];
$adopter_contact = $row['adopter_contact'];
$animal_type = $row['animal_type'];
$breed = $row['breed'];

if (isset($_POST['submit'])) {
    // Retrieve updated values from the form
    $adopter_name = $_POST['adopter_name'];
    $adoption_date = $_POST['adoption_date'];
    $adopter_loc = $_POST['adopter_loc'];
    $adopter_contact = $_POST['adopter_contact'];
    $animal_type = $_POST['animal_type'];
    $breed = $_POST['breed'];

    // Update the record in the database
    $sql = "UPDATE manage_user SET adopter_name='$adopter_name', adoption_date='$adoption_date', adopter_loc='$adopter_loc', adopter_contact='$adopter_contact', animal_type='$animal_type', breed='$breed' WHERE id=$id";

    $result = mysqli_query($con, $sql);
    if ($result) {
        header('location: manage_users.php');
        exit; // Stop further execution after redirect
    } else {
        die("Update failed: " . mysqli_error($con));
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
    <div class="container my-5">
        <form method="post">
            <div class="mb-3">
                <label>Adopter Name</label>
                <input type="text" class="form-control" placeholder="Enter the Adopter Name" name="adopter_name" autocomplete="off" value="<?php echo $adopter_name; ?>">
            </div>
            <div class="mb-3">
                <label>Adoption Date</label>
                <input type="text" class="form-control" placeholder="Enter the Adoption Date" name="adoption_date" autocomplete="off" value="<?php echo $adoption_date; ?>">
            </div>
            <div class="mb-3">
                <label>Adopter Location</label>
                <input type="text" class="form-control" placeholder="Enter the Adopter Location" name="adopter_loc" autocomplete="off" value="<?php echo $adopter_loc; ?>">
            </div>
            <div class="mb-3">
                <label>Adopter Contact Details</label>
                <input type="text" class="form-control" placeholder="Enter the Adopter Contact" name="adopter_contact" autocomplete="off" value="<?php echo $adopter_contact; ?>">
            </div>
            <div class="mb-3">
                <label>Adopted Animal Type</label>
                <input type="text" class="form-control" placeholder="Enter the Adopted Animal Type" name="animal_type" autocomplete="off" value="<?php echo $animal_type; ?>">
            </div>
            <div class="mb-3">
                <label>Adopted Animal Breed</label>
                <input type="text" class="form-control" placeholder="Enter the Adopted Animal Breed" name="breed" autocomplete="off" value="<?php echo $breed; ?>">
            </div>
            
            <button type="submit" name="submit" class="btn btn-primary">Submit</button>&nbsp;
            <button class="btn btn-primary my-5"><a href="manage_users.php" class="text-light">Cancel</a></button>
        </form>
    </div>
</body>
</html>