<?php
include 'admin_panel.php';

// Assuming you have a database connection logic here
// $con = mysqli_connect("hostname", "username", "password", "database_name");

if (isset($_POST['submit'])) {

    $breed = $_POST['breed'];
    $diagnosis = $_POST['diagnosis'];
    $treatment = $_POST['treatment'];
    $treatment_date = $_POST['treatment_date'];

    // Insert data into the database
    $sql = "INSERT INTO medico_records (breed, diagnosis, treatment, treatment_date) 
    VALUES ('$breed', '$diagnosis', '$treatment', '$treatment_date')";

    $result = mysqli_query($con, $sql);

    if ($result) {
        header('location: medicalrecords.php');
        exit();
    } else {
        die(mysqli_error($con));
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
    <div class="container my-5" >
        <form method="post">
           
            <div class="mb-3">
                <label>Animal Breed</label>
                <input type="text" class="form-control" placeholder="Enter the animal breed" name="breed" autocomplete="off">
            </div>
            <div class="mb-3">
                <label>Diagnosis</label>
                <input type="text" class="form-control" placeholder="Enter the Diagnosis name" name="diagnosis" autocomplete="off">
            </div>
            <div class="mb-3">
                <label>Treatment</label>
                <input type="text" class="form-control" placeholder="Enter the Treatment Name" name="treatment" autocomplete="off">
            </div>
            <div class="mb-3">
                <label>Treatment Date</label>
                <input type="text" class="form-control" placeholder="Enter the Treatment Date" name="treatment_date" autocomplete="off">
            </div>
            
            <button type="submit" name="submit" class="btn btn-primary">Submit</button> &nbsp;
            <button class="btn btn-primary my-5"><a href="medicalrecords.php" style="color: white; text-decoration: none;">Cancel</a></button>


        </form>
    </div>
</body>
</html>
