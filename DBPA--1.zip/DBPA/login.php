<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the request is for login or signup
    if (isset($_POST['username']) && isset($_POST['password'])) {
        // Login process
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Database connection
        $conn = new mysqli('localhost', 'root', '', 'test1');
        if ($conn->connect_error) {
            die('Connection failed : ' . $conn->connect_error);
        }

        // Check if the admin user exists with the provided credentials
        $stmt = $conn->prepare("SELECT * FROM login WHERE newUsername=? AND newPassword=?");
        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Admin user exists with the provided credentials
            echo '<script>alert("Login successful"); window.location.href = "admin_panel.html";</script>';
            exit();
        } else {
            // Invalid username or password
            echo '<script>alert("Invalid username or password"); window.location.href = "login1.html";</script>';
            exit();
        }
    } elseif (isset($_POST['newUsername']) && isset($_POST['newPassword']) && isset($_POST['secretKey'])) {
        // Signup process
        $newUsername = $_POST['newUsername'];
        $newPassword = $_POST['newPassword'];
        $providedSecretKey = $_POST['secretKey'];

        // Check if the provided secret key is correct
        $correctSecretKey = '2924';

        if ($providedSecretKey !== $correctSecretKey) {
            echo '<script>alert("Invalid secret key"); window.location.href = "login1.html";</script>';
            exit();
        }

        // Database connection
        $conn = new mysqli('localhost', 'root', '', 'test1');
        if ($conn->connect_error) {
            die('Connection failed : ' . $conn->connect_error);
        }

        // Check if the admin user already exists
        $stmt = $conn->prepare("SELECT * FROM login WHERE newUsername=?");
        $stmt->bind_param("s", $newUsername);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Admin user already exists
            echo '<script>alert("Admin user already exists"); window.location.href = "login1.html";</script>';
            exit();
        }

        // Add the admin user to the database
        $stmt = $conn->prepare("INSERT INTO login (newUsername, newPassword) VALUES (?, ?)");
        $stmt->bind_param("ss", $newUsername, $newPassword);
        $stmt->execute();

        // Redirect to admin_panel.html after successful signup
        echo '<script>alert("Admin signup successful"); window.location.href = "admin_panel.html";</script>';
        exit();
    }
}
?>
