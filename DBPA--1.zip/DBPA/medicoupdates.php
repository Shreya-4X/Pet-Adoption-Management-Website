<?php
include 'admin_panel.php';

$id = $_GET['updateid'];

// Fetch data from the database based on the provided ID
$sql = "SELECT * FROM medico_records WHERE id=$id";
$result = mysqli_query($con, $sql);
$row = mysqli_fetch_assoc($result);

// Populate variables with fetched data
$breed = $row['breed'];
$diagnosis = $row['diagnosis'];
$treatment = $row['treatment'];
$treatment_date = $row['treatment_date'];

if (isset($_POST['submit'])) {
    // Retrieve updated values from the form
    $breed = $_POST['breed'];
    $diagnosis = $_POST['diagnosis'];
    $treatment = $_POST['treatment'];
    $treatment_date = $_POST['treatment_date'];

    // Update the record in the database
    $sql = "UPDATE medico_records SET breed='$breed', diagnosis='$diagnosis', treatment='$treatment', treatment_date='$treatment_date' WHERE id=$id";

    $result = mysqli_query($con, $sql);
    if ($result) {
        header('location: medicalrecords.php');
        exit; // Stop further execution after redirect
    } else {
        die("Update failed: " . mysqli_error($con));
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
    <div class="container my-5">
        <form method="post">
            <div class="mb-3">
                <label>Animal Breed</label>
                <input type="text" class="form-control" placeholder="Enter the Animal Breed" name="breed" autocomplete="off" value="<?php echo $breed; ?>">
            </div>
            <div class="mb-3">
                <label>Diagnosis</label>
                <input type="text" class="form-control" placeholder="Enter the Diagnosis" name="diagnosis" autocomplete="off" value="<?php echo $diagnosis; ?>">
            </div>
            <div class="mb-3">
                <label>Treatment</label>
                <input type="text" class="form-control" placeholder="Enter the Treatment Given" name="treatment" autocomplete="off" value="<?php echo $treatment; ?>">
            </div>
            <div class="mb-3">
                <label>Treatment Date</label>
                <input type="text" class="form-control" placeholder="Enter the Treatment Date" name="treatment_date" autocomplete="off" value="<?php echo $treatment_date; ?>">
            </div>
            
            <button type="submit" name="submit" class="btn btn-primary">Submit</button>&nbsp;
            <button class="btn btn-primary my-5"><a href="medicalrecords.php" class="text-light">Cancel</a></button>
        </form>
    </div>
</body>
</html>
