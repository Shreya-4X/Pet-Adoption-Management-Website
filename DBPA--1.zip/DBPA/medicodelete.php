<?php
include 'admin_panel.php';
if(isset($_GET['deleteid'])){
    $id=$_GET['deleteid'];

    $sql="delete from medico_records where id=$id";
    $result=mysqli_query($con,$sql); // Corrected function call
    if($result){
        header('location:medicalrecords.php');
    }
    else{
        die(mysqli_error($con));
    }
}
?>