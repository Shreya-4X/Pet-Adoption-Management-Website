<?php

$con=mysqli_connect('localhost','root','','test1');
if(!$con){
    die(mysqli_error($con));
}
?>